enum ScreenStatesEnum {
  isLoading,
  ready,
  error,
}

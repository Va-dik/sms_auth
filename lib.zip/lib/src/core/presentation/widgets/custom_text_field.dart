import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sms_auth/src/core/presentation/widgets/constants/colors_constant.dart';

class CustomTextField extends StatefulWidget {
  final Color? textColor;
  final bool border;
  final EdgeInsets? padding;
  final TextInputType? textInputType;
  final List<TextInputFormatter>? inputFormatters;
  final void Function(String value) onChanged;
  final TextEditingController controller;

  const CustomTextField({
    Key? key,
    this.textColor = CoreColorsConstant.textFieldBorderDefaultColor,
    this.border = false,
    this.padding = const EdgeInsets.symmetric(vertical: 12),
    this.inputFormatters,
    required this.onChanged,
    required this.controller,
    this.textInputType,
  }) : super(key: key);

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  bool isPressed = false;

  @override
  Widget build(BuildContext context) {
    return CupertinoTextField(
      inputFormatters: widget.inputFormatters,
      keyboardType: TextInputType.number,
      controller: widget.controller, // Используйте созданный контроллер
      padding: widget.padding!,
      placeholderStyle: const TextStyle(
        color: CoreColorsConstant.textFieldPlaceholderColor,
        fontSize: 17,
        fontWeight: FontWeight.w400,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: widget.border
            ? Border.all(
                width: 1,
                color: isPressed
                    ? CoreColorsConstant.textFieldBorderPressedColor
                    : CoreColorsConstant.textFieldBorderDefaultColor,
              )
            : null,
        borderRadius: BorderRadius.circular(10),
      ),
      onTap: widget.border? () {
        setState(() => isPressed = true);
      } : null,
      onSubmitted: (value) {
        setState(() => isPressed = false);
      },
      onTapOutside: (event) {
        FocusScope.of(context).unfocus();
        setState(() => isPressed = false);
      },
      onChanged: widget.onChanged,
    );
  }
}

import 'package:sms_auth/src/core/components/enums/screen_states_enum.dart';

class SignInState {
  final int? step;
  final int stepLength = 3;
  final ScreenStatesEnum screenState;

  const SignInState({
    this.step = 1,
    this.screenState = ScreenStatesEnum.ready,
  });

  SignInState copyWith({
    int? step,
    ScreenStatesEnum? screenState,
  }) {
    return SignInState(
      step: step ?? this.step,
      screenState: screenState ?? this.screenState,
    );
  }
}

class ErrorSignInState extends SignInState {
  final String errorMessage;

  ErrorSignInState({required this.errorMessage});
}

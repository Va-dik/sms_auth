import 'package:sms_auth/src/features/sign_in/data/models/phone_number_model.dart';

abstract class SignInEvent {
  const SignInEvent();
}

class SendSmsCodeEvent extends SignInEvent {
  final PhoneNumberModel phoneNumber;

  const SendSmsCodeEvent({required this.phoneNumber});
}

class StepCounterManagementEvent extends SignInEvent {
  final StepCounterActionEnum stepCounterAction;

  const StepCounterManagementEvent({required this.stepCounterAction});
}

class UpdateStateEvent extends SignInEvent {
  const UpdateStateEvent();
}

enum StepCounterActionEnum { back, next }

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sms_auth/src/core/components/enums/screen_states_enum.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_events.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_state.dart';

final class SignInBloc extends Bloc<SignInEvent, SignInState> {
  SignInBloc() : super(const SignInState()) {
    on<SendSmsCodeEvent>(_sendCode);
    // on<SendSmsCodeEvent>(_reSendCode);
    on<UpdateStateEvent>(_updateState);
    on<StepCounterManagementEvent>(_stepCounterManagementEvent);
  }

  Future<void> _sendCode(
      SendSmsCodeEvent event, Emitter<SignInState> emit) async {
    event.phoneNumber.phoneNumber;
  }

  void _updateState(UpdateStateEvent event, Emitter<SignInState> emit) async {
    emit(state.copyWith(screenState: ScreenStatesEnum.ready));
  }

  Future<void> _reSendCode(
      SendSmsCodeEvent event, Emitter<SignInState> emit) async {}

  void _stepCounterManagementEvent(
      StepCounterManagementEvent event, Emitter<SignInState> emit) {
    switch (event.stepCounterAction) {
      case StepCounterActionEnum.next:
        {
          if (state.step! < 3) {
            emit(state.copyWith(step: state.step! + 1));
            break;
          }
        }
      case StepCounterActionEnum.back:
        {
          if (state.step! > 1) {
            emit(state.copyWith(step: state.step! - 1));
            break;
          }
        }
      default:
        break;
    }
  }
}

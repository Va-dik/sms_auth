import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_bloc.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_events.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_colors.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_strings.dart';

class CustomButton extends StatelessWidget {
  const CustomButton({
    super.key,
    required this.isButtonEnabled,
  });

  final bool isButtonEnabled;

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      borderRadius: const BorderRadius.all(Radius.circular(10)),
      color: ColorsConstant.sendCodeButtonActiveColor,
      pressedOpacity: 0.6,
      disabledColor: ColorsConstant.sendCodeButtonInactiveColor,
      onPressed: isButtonEnabled
          ? () {
              context.read<SignInBloc>().add(const StepCounterManagementEvent(
                  stepCounterAction: StepCounterActionEnum.next));
            }
          : null,
      child: const Text(
        StringsConstant.sendSmsCode,
        style: TextStyle(
          color: Color(0xFF4E4E4E),
          fontSize: 16,
          letterSpacing: 0.05,
        ),
      ),
    );
  }
}

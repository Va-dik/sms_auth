import 'package:flutter/material.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_colors.dart';

abstract class IconsConstant {
  static const doneIcon = Icon(
    Icons.check_circle_outline,
    color: ColorsConstant.stepPointDoneIconColor,
    size: 36,
  );
  static const appBarLeadingIcon = Icon(
    Icons.arrow_back_ios_new,
    color: ColorsConstant.appBarLeadingIconColor,
    size: 36,
  );
}

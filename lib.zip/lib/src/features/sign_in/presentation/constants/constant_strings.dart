abstract class StringsConstant {
  static const registration = 'Регистрация';
  static const inputNumForReg = 'Введите номер телефона\nдля регистрации';
  static const phoneNum = 'Номер теефона';
  static const sendSmsCode = 'Отправить смс-код';
  static const personalDataInfo =
      'Нажимая на данную кнопку, вы даете согласие на обработку ';
  static const personalData = 'персональных данных';
}

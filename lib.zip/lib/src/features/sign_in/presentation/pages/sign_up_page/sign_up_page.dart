import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:sms_auth/src/core/components/enums/screen_states_enum.dart';
import 'package:sms_auth/src/core/presentation/widgets/custom_text_field.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_bloc.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_events.dart';
import 'package:sms_auth/src/features/sign_in/presentation/bloc/sign_in_state.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_strings.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_colors.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_icons.dart';
import 'package:sms_auth/src/features/sign_in/presentation/pages/sign_up_page/sign_up_body.dart';
import 'package:sms_auth/src/features/sign_in/presentation/widgets/custom_button.dart';
import 'package:sms_auth/src/features/sign_in/presentation/widgets/step_point.dart';

class SignUpPage extends StatelessWidget {
  const SignUpPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        border: null,
        leading: IconButton(
          icon: IconsConstant.appBarLeadingIcon,
          onPressed: () {},
        ),
      ),
      child: BlocProvider<SignInBloc>(
        create: (context) => SignInBloc(),
        child: SafeArea(
          child:
              BlocBuilder<SignInBloc, SignInState>(builder: (context, state) {
            switch (state.screenState) {
              case ScreenStatesEnum.error:
                return const Scaffold(
                  body: Center(child: Text("Ошибка загрузки данных")),
                );
              case ScreenStatesEnum.isLoading:
                return const CircularProgressIndicator();
              case ScreenStatesEnum.ready:
                return _buildHeader(context, state);
            }
          }),
        ),
      ),
    );
  }

  Column _buildHeader(BuildContext context, SignInState state) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Building steps and dividers
            for (int index = 0; index < state.stepLength; index++) ...{
              StepPoint(
                step: index + 1,
                currentStep: state.step!,
              ),
              if (index < state.stepLength - 1) divider()
            }
          ],
        ),
        const Padding(
          padding: EdgeInsets.only(top: 30),
          child: Text(
            StringsConstant.registration,
            style: TextStyle(
              color: ColorsConstant.registrationTextColor,
              fontSize: 34,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.37,
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.only(top: 20),
          child: Text(
            StringsConstant.inputNumForReg,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF4E4E4E),
              fontSize: 16,
              fontFamily: 'SF Pro Text',
              fontWeight: FontWeight.w400,
              height: 1.3,
            ),
          ),
        ),
        SignUpBody(),
      ],
    );
  }

  Container divider() {
    return Container(
      width: 50,
      height: 1,
      color: ColorsConstant.dividerColor,
    );
  }
}

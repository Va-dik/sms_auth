import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:sms_auth/src/core/presentation/widgets/custom_text_field.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_colors.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_strings.dart';
import 'package:sms_auth/src/features/sign_in/presentation/widgets/custom_button.dart';

class SignUpBody extends StatefulWidget {
  SignUpBody({super.key});

  @override
  State<SignUpBody> createState() => _SignUpBodyState();
}

class _SignUpBodyState extends State<SignUpBody> {
  final TextEditingController _phoneNumberController =
      TextEditingController(text: '+7');

  final String countryCode = '+7';

  final mask = MaskTextInputFormatter(
    mask: '+7 (###) ### ## ##',
    filter: {'#': RegExp(r'[0-9]')},
  );

  bool _isButtonEnabled() {
    return (_phoneNumberController.text.length > 7);
  }

  void _showDialog(BuildContext context) {
    showCupertinoDialog(
      barrierDismissible: true,
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('Инфо'),
        content: const Text('Ваши персональные данные будут переданы.'),
        actions: [
          CupertinoButton.filled(
            child: const Text('Ok'),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 50),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            StringsConstant.phoneNum,
            style: TextStyle(
                color: ColorsConstant.phoneNumberTextColor, fontSize: 12),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: CustomTextField(
              controller: _phoneNumberController,
              onChanged: (value) {
                setState(() {
                  // context.read<SignInBloc>().add(const UpdateStateEvent());
                });
              },
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              border: true,
              inputFormatters: [mask],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 120),
            child: Center(
              // КНОПКА //////////////
                child: CustomButton(isButtonEnabled: _isButtonEnabled())),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                    text: StringsConstant.personalDataInfo,
                    style: const TextStyle(
                        fontSize: 12,
                        color: ColorsConstant.personalDataInfoTextColor),
                    children: [
                      TextSpan(
                          text: StringsConstant.personalData,
                          style: const TextStyle(
                              color: ColorsConstant.personalDataTextColor),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () => _showDialog(context))
                    ])),
          )
        ],
      ),
    );
  }
}

import 'package:flutter/cupertino.dart';

class PhoneNumberModel {
  final String phoneNumber;
  const PhoneNumberModel({this.phoneNumber = ''});
}

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sms_auth/src/features/account/presentation/bloc/account_events.dart';
import 'package:sms_auth/src/features/account/presentation/bloc/account_state.dart';

final class AccountBloc extends Bloc<AccountEvent, AccountState> {
  AccountBloc() : super(AccountState()) {
    on<EditAccountEvent>(_editAccountEvent);
  }

  Future<void> _editAccountEvent(
      EditAccountEvent event, Emitter<AccountState> emit) async {}
}

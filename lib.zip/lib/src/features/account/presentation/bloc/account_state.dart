import 'package:sms_auth/src/core/components/enums/screen_states_enum.dart';
import 'package:sms_auth/src/features/account/data/models/account_model.dart';

class AccountState {
  final AccountModel? account;
  final ScreenStatesEnum screenState;
  final String? errorMessage;

  AccountState({this.account, this.screenState = ScreenStatesEnum.ready, this.errorMessage});

  AccountState copyWith(AccountModel? account, ScreenStatesEnum? screenState, String? errorMessage) {
    return AccountState(
      account: account ?? this.account,
      screenState: screenState ?? this.screenState,
      errorMessage: errorMessage?? this.errorMessage
    );
  }
}

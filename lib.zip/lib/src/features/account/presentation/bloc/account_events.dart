import 'package:sms_auth/src/features/account/data/models/account_model.dart';

abstract class AccountEvent {
  const AccountEvent();
}

class EditAccountEvent extends AccountEvent {
  final AccountModel account;
  const EditAccountEvent({required this.account});
}

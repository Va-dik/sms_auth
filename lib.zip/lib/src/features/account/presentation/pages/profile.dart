
// class AccountPage extends StatelessWidget {
//   const AccountPage({super.key});


//   @override
//   Widget build(BuildContext context) {
//     return CupertinoPageScaffold(
//       child: SafeArea(child: _buildHeader()),
//     );
//   }

// }

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:sms_auth/src/features/sign_in/presentation/constants/constant_colors.dart';
import 'package:sms_auth/src/features/sign_in/presentation/pages/sign_up_page/sign_up_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return  CupertinoApp(
      theme: const CupertinoThemeData(
        barBackgroundColor: ColorsConstant.scaffoldBgColor,
        scaffoldBackgroundColor: ColorsConstant.scaffoldBgColor,
      ),
      title: 'Sms Auth',
      home: SignUpPage(),
    );
  }
}
